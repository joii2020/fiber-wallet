import { Config } from "./types";
export declare function assertHashType(debugPath: string, hashType: string): void;
export declare function validateConfig(config: Config): void;
export declare function getConfig(): Config;
export declare function initializeConfig(inputConfig: Config): void;
//# sourceMappingURL=manager.d.ts.map